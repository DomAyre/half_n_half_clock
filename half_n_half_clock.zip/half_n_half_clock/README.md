# Half n Half Clock

This app is a half analogue and half digital clock.
It has a light theme and a dark theme, and displays sample weather and location data.

<img src='half_n_half_dark.png' width='350'>

<img src='half_n_half_light.png' width='350'>
